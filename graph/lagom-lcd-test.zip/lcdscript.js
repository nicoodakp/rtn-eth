// helper scripts for http://www.lagom.nl/lcd-test/ and the offline version.
// Copyright 2007, Han-Kwang Nienhuys

// language-specific stuff goes in lcdscript_xx.js (xx=language code)

// are we framed?
function check_frame()
{
    dl = window.location;
    tl = top.location;
    
    // try/catch block since Opera does not allow reading of
    // variables belonging to other web sites
    var externalframe=0;
    try { x = tl.href; }
    catch (e) {
    	  allowed = document.referrer.match(RegExp("^http://www.lexicool.com/", ""));
    	  externalframe = (!allowed);
    }
    if (!externalframe && tl.href != dl.href) {
	tlhref = tl.href;
	if (!tlhref.match(RegExp("^http://(localhost|ordbok2?\.lagom\.nl)/", ""))) {
	    externalframe = 1;
	}
    }
    if (externalframe) {
       setTimeout("tl.href = dl.href;", 2000);
    }
}

check_frame();

var hwin = '';
function helpwin(url) {
   if (!hwin.closed && hwin.location) {
      hwin.close();
   }
   hwin = window.open(url, "lcdhelp",
      'toolbar=0,scrollbars=1,location=0,statusbar=1,menubar=0,resizable=1,width=500,height=400');
   hwin.focus();
}


// Get window width, height in pixels; returns 1024x768 width if unidentifiable.
// borrowed from http://www.xs4all.nl/~sbpoley/webmatters/resize.html
function getWindowWidth() 
{
     var ww = 1024;
     d = document;
     if ( typeof window.innerWidth != 'undefined' )
	  ww = window.innerWidth;  // NN and Opera version
     else if ( d.documentElement
	       && typeof d.documentElement.clientWidth!='undefined'
	       && d.documentElement.clientWidth != 0 )
	  ww = d.documentElement.clientWidth;
     else if ( d.body
	       && typeof d.body.clientWidth != 'undefined' )
	  ww = d.body.clientWidth;
   return ww;
}
function getWindowHeight()
{
     var wh = 768;
     d = document;
     if ( typeof window.innerHeight != 'undefined' )
	  wh = window.innerHeight;  // NN and Opera version
     else if ( d.documentElement
	       && typeof d.documentElement.clientHeight!='undefined'
	       && d.documentElement.clientHeight != 0 )
	  wh = d.documentElement.clientHeight;
     else if ( d.body
	       && typeof d.body.clientHeight != 'undefined' )
	  wh = d.body.clientHeight;
   return wh;
}




// resize imgs and divs to window size
function imgsize() {
    var imagelist = ["angle_purple", "angle_red", "angle_green", "angle_blue", "invpattern", "clockcalib", "angleGrey"];
    var substract_size = [0,0,0,0,0,2,0]; // reduce wxh with this amount
    var multiply_y=[1.05, 1.05, 1.05, 1.05, 1.05, 1.05, 1.05];
    var xres = getWindowWidth();
    var yres = getWindowHeight();
    for (i = 0; i < imagelist.length; ++i) {
        var elm = document.getElementById(imagelist[i]);
	if (elm) {
	    hgt = Math.round(yres * multiply_y[i] - substract_size[i]);
	    wid = Math.round(xres - substract_size[i]);
	    elm.style.width = wid + "px";
	    elm.style.height = hgt + "px";
	}
    }
    cr_blocksize(); // contrast-ratio page specifics
    // and set the resolution
    update_resolution();
}

// contrast ratio page: resize divs to window size
function cr_blocksize() {
    if (!document.getElementById("cr_whiteblock"))
	return;
    var blocklist = ["cr_whiteblock", "cr_blackblock"];
    var xres = getWindowWidth();
    var yres = getWindowHeight();
    for (i = 0; i < blocklist.length; ++i) {
        var elm = document.getElementById(blocklist[i]);
	if (elm) {
	    //	     elm.style.width = (xres*0.94-4) + "px";
	     elm.style.height = (yres*0.94-4) + "px";
	}
    }
   var tdlist = document.getElementById("cr_checker").getElementsByTagName("td");
   var tdwid = (xres*0.235-1) + "px";
   var tdhgt = (yres*0.313-1) + "px";
   for (i = 0; i < tdlist.length; ++i) {
	tdlist[i].style.width = tdwid;
	tdlist[i].style.height = tdhgt;
   }
   tdlist = document.getElementById("cr_twoblocks").getElementsByTagName("td");
   var tdwid = (xres*0.47-2) + "px";
   var tdhgt = (yres*0.94-4) + "px";
   for (i = 0; i < tdlist.length; ++i) {
	tdlist[i].style.width = tdwid;
	tdlist[i].style.height = tdhgt;
   }
}


// resize images on window resize
window.onresize = imgsize;

// Browsers have problems with jumping to in-document anchors because
// of image resizing after jumping to the anchor
function checkanchor()
{
    u = document.URL;
    a = u.match('#.*$');
    if (a) {
	document.location = a;
    }
}


// gamma calibration checkers/stripes swap
var gamma_no = 0;
function swap_dvi_vga() {
//     img1 = document.getElementById("gammatest.png");
     img2 = document.getElementById("sharpness-d.png");
     if (gamma_no == 0) {
	  img2.src = "http://www.lagom.nl/lcd-test/img/sharpness-a.png";
	  gamma_no = 1;
     } else {
	  img2.src = "http://www.lagom.nl/lcd-test/img/sharpness-d.png";
	  gamma_no = 0;
     }
     return false;
}

// onclick on div
function goanchor(a)
{
    document.location.href = "#" + a;
    return false;
}

// functions for inversion patterns

var ipfilenrs=["1", "2a", "2b", "3", "4a", "4b", "5", "6a", "6b", "7a", "7b"];
var ipnum=11;
var ipcurr=ipnum-1;
function nextpattern() {
    ipcurr = (ipcurr+1) % ipnum;
    updatepattern();
    return false;
}
function prevpattern() {
    ipcurr = (ipcurr-1+ipnum
	      ) % ipnum;
    updatepattern();
    return false;
}
function setpattern(n) {
    ipcurr = n;
}
function updatepattern() {
    elm = document.getElementById("invpattern");
    tmp = "url(\"bgimg/inversion-" + ipfilenrs[ipcurr]  +".png\")";
    elm.style.background = tmp;
    elm = document.getElementById("currentdesc");
    elm.innerHTML = ipfilenrs[ipcurr];
    return false;
}

// update display resolution in HTML (id="yourResolution"), 
// and load web bug for resolution statistics (id="statimg")
function update_resolution() {
   var elm = document.getElementById("yourResolution");
   if (!elm)
       return;
    
   var w = screen.width;
   var h = screen.height;
   var cd = 1*screen.colorDepth;

   var minw = 1024;
   var minh = 768;
   var ref_year = 2007;
   var refer = document.referrer;
   if (refer.indexOf("small") != -1) {
      minw = 320;
      minh = 240;
      refer = "small";
   } else 
      refer = "big";
   
   
   var res_names =
       [
        "320x240", "QVGA 4:3",
        "240x320", "QVGA 3:4",
        "320x396", "iPod 4:5",
        "480x320", "HVGA 3:2",
        "640x480", "VGA 4:3",
        "800x600", "SVGA 4:3",
        "800x480", "WVGA 5:3",
        "1024x768", "XGA 4:3",
        "1152x864", "XGA+ 4:3",
        "1280x1024", "SXGA 5:4",
        "1280x720", "720p 16:9",
        "1280x768", "WXGA 5:3",
        "1280x800", "WXGA 16:10",
        "1280x854", "3:2",
        "1280x960", "4:3",
        "1360x768", "WXGA 16:9",
        "1366x768", "WXGA 16:9",
        "1440x900", "WXGA+ 16:10",
        "1400x1050", "SXGA+ 4:3",
        "1600x1200", "UXGA 4:3",
        "1680x1050", "WSXGA+ 16:10",
        "1920x1200", "WUXGA 16:10",
        "2560x1600", "WQXGA 16:10"
	];
   
    if (w && h) {
	var res = w + "x" + h;
	var longres = res;
	var comment = "";
	var common = 0;
	for (i = 0; i < res_names.length; i+=2) {
	    if (res_names[i] == res) {
		if (res_desc[res]) 
		    comment = res_desc[res] + " (" + resmsg_as_of(ref_year) + ')';
		else
		    comment = '';
		longres = "<b>" + res + "</b> &nbsp; (" + res_names[i+1] + ")";
		common = 1;
		break;
	    }
	}
	if (w < minw || h < minh)
	    comment +=  '<br>' + res_msg['lowres'];
	if (!common)
	    comment +=  '<br>' + res_msg['uncommon'];
	aspect = 1.0*w/h;
	if (aspect < 1) {
	    comment += '<br>'+res_msg['portrait'];
	} else if (Math.abs(aspect-1.333) > 0.01 &&
		   Math.abs(aspect-1.25) > 0.01 && Math.abs(aspect-1.6) > 0.01) {
	    aspect = Math.round(aspect*100)*0.01;
	    comment += '<br>' + res_msg['uncommon ratio'] + aspect + '.';
	}
	var cddesc = "";
	if (cd == 16) {
	    cddesc = res_msg['16bpp'];
	} else if (cd == 24 || cd == 32) {
	    cddesc = res_msg['24bpp'];
	} else if (cd == 8) {
	    cddesc = res_msg['8bpp'];
	}
	if (cddesc != '')
	    cddesc = ' (' + cddesc + ')';
	elm.innerHTML = res_msg['resolution'] + ': ' + longres + "<br>" +
	    res_msg['description'] + ': ' + comment + "<br>" +
	    res_msg['color depth'] + ': ' + resmsg_bits(cd) + cddesc;
	if (cd < 24) {
	    elm.innerHTML += '<br>' + res_msg['bppwarning'];
	}	
	// collect statistics
	img = document.getElementById("statimg");
	if (img) {
	    var cd1 = cd;
	    if (cd1 == 32)
		cd1 = 24; // no separate stats for 32/24 bpp
	    img.src = "/lcd-test/stats?lcd=" + res + "," + cd1 + "bpp," + refer;
	}
    } else {
	elm.innerHTML = res_msg["unknown"];
    }
}

function check_portrait()
{
    if (screen.width >= screen.height)
	return;
    elm = document.getElementById('portrait_remark');
    if (elm) {
	elm.innerHTML = res_msg['this test portrait'];
    }	
}

// onload function
function index_init()
{
    imgsize();
    checkanchor();
    check_portrait();
}


// get current value of form <select> tag
function getform_select(name)
{
    selecttag = document.getElementsByName(name);
    if (!selecttag || selecttag.length == 0)
	return;
    var s0 = selecttag[0];
    var opttags = s0.getElementsByTagName('option');
    var i;
    for (i = 0; i < opttags.length; ++i) {
	if (opttags[i].selected) {
	    return opttags[i].value;
	}	    
    }
}


// go to specified page, prepend language, append .php (e.g. contrast -> zhs_contrast.php)
function go_page(page)
{
    if (page == 'index' && lang == 'en')
	document.location.href = './';
    else if (lang == 'en')
	document.location.href = page + '.php'; // e.g. contrast.php
    else
	document.location.href = lang + '_' + page + '.php';  // e.g. zhs_contrast.php
}


// go to page specified by select input and current language
function go_page_select(inputname)
{
    go_page(getform_select(inputname));
}

// go to new language (take from select inputname)
function switch_language(page, inputname)
{
    lang = getform_select(inputname); // global
    go_page(page);
}


// for narrow screens: start a new row in the icon list at the top 
function iconlist_break()
{
   var w = screen.width;
   if (w < 1024)
       document.write("</td></tr></table>\n<table><tr>\n");
   else
       document.write("</td>\n");
}